package com.aiinty.lab25;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ImageButton[][] buttons;
    private TextView winnersText;
    private TicTac game;
    private boolean gameEnded = false;
    private int krestikiWins = 0;
    private int nolikiWins = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        game = new TicTac();
        winnersText = findViewById(R.id.winners);

        buttons = new ImageButton[][]{
                {findViewById(R.id.b_1_1), findViewById(R.id.b_1_2), findViewById(R.id.b_1_3)},
                {findViewById(R.id.b_2_1), findViewById(R.id.b_2_2), findViewById(R.id.b_2_3)},
                {findViewById(R.id.b_3_1), findViewById(R.id.b_3_2), findViewById(R.id.b_3_3)},
        };

        findViewById(R.id.reset).setOnClickListener(v -> {
            game = new TicTac();

            for (ImageButton[] row : buttons) {
                for (ImageButton b : row) {
                    b.setImageDrawable(null);
                }
            }

            gameEnded = false;
            switchPlayer('X');
        });

        for (int i = 0; i < buttons.length; i++) {
            for (int j = 0; j < buttons.length; j++) {
                ImageButton b = buttons[i][j];
                int x = i;
                int y = j;
                b.setOnClickListener(v -> {
                    if (gameEnded) {
                        return;
                    }

                    if (game.isValidMove(x, y)) {
                        char current = game.getCurrentPlayer();
                        game.makeMove(x, y);
                        if (!game.checkWinner()) {
                            switchPlayer(game.getCurrentPlayer());
                        }

                        b.setImageDrawable(getDrawable(current == 'X' ? R.drawable.baseline_crop_24 : R.drawable.ic_launcher_background));
                    }

                    if (!game.checkWinner() && game.isBoardFull()) {
                        Toast.makeText(this, "Ничья", Toast.LENGTH_SHORT).show();
                        gameEnded = true;
                        return;
                    }

                    if (game.checkWinner()) {
                        char winner = game.getPrevPlayer();
                        switch (winner) {
                            case 'X':
                                krestikiWins++;
                                break;
                            case '0':
                                nolikiWins++;
                                break;
                        }
                        winnersText.setText("Крестики: " + krestikiWins + " Нолики: " + nolikiWins);
                        Toast.makeText(this, "Выиграл: " + winner, Toast.LENGTH_SHORT).show();

                        gameEnded = true;
                    }


                });
            }
        }
    }

    public void switchPlayer(char nextPlayer) {
        TextView krestikiView = findViewById(R.id.krestikiview);
        TextView nolikiView = findViewById(R.id.nolikiview);

        if (nextPlayer == 'X') {
            krestikiView.setTextColor(getColor(R.color.blue));
            nolikiView.setTextColor(getColor(R.color.black));
        } else {
            krestikiView.setTextColor(getColor(R.color.black));
            nolikiView.setTextColor(getColor(R.color.blue));
        }
    }
}