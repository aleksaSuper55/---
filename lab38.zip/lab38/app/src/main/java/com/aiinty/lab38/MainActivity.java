package com.aiinty.lab38;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.os.Handler;

import com.google.android.material.divider.MaterialDividerItemDecoration;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static int METROV_OT_VAS = 6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ComplexRecyclerViewAdapter complexRecyclerViewAdapter =
                new ComplexRecyclerViewAdapter(getSampleArrayList(), this);
        RecyclerView recyclerView = findViewById(R.id.rv);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(complexRecyclerViewAdapter);

        MaterialDividerItemDecoration decoration = new MaterialDividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        decoration.setDividerInsetStart(16);
        decoration.setDividerInsetEnd(16);

        recyclerView.addItemDecoration(decoration);

        SwipeRefreshLayout swipeRefreshLayout = findViewById(R.id.swo);
        swipeRefreshLayout.setColorSchemeColors(
                getColor(android.R.color.holo_blue_bright),
                getColor(android.R.color.holo_green_light),
                getColor(android.R.color.holo_orange_light),
                getColor(android.R.color.holo_red_light)
        );
        swipeRefreshLayout.setOnRefreshListener(() ->
                new Handler().postDelayed(() -> {
                    complexRecyclerViewAdapter.updateData((ArrayList<User>) getSampleArrayList());
                    swipeRefreshLayout.setRefreshing(false);
                }, 2000)
        );
    }

    private List<User> getSampleArrayList() {
        ArrayList<User> items = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            items.add(new User("IVAN MAZUR", METROV_OT_VAS + " метров от вас", R.drawable.elena));
            METROV_OT_VAS--;
        }
//        items.add(new User("Anna Ivanova", "30 метров от вас", R.drawable.elena));
//        items.add(new User("Sergey Petrov", "30 метров от вас",  R.drawable.elena));
//        items.add(new User("IVAN MAZUR", "5 метров от вас", R.drawable.elena));
//        items.add(new User("Olga Smirnova", "30 метров от вас",  R.drawable.elena));
//        items.add(new User("IVAN MAZUR", "2 метров от вас", R.drawable.elena));
//        items.add(new User("Alexey Volkov", "30 метров от вас", R.drawable.elena));
        return items;
    }
}