package com.aiinty.lab35;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import com.google.android.material.divider.MaterialDivider;
import com.google.android.material.divider.MaterialDividerItemDecoration;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Contact> contacts;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rv = findViewById(R.id.rvContacts);

        contacts = Contact.createContactsList(20);
        ContactsAdapter adapter = new ContactsAdapter(contacts, this);
        rv.setAdapter(adapter);

        MaterialDividerItemDecoration decoration = new MaterialDividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        decoration.setDividerInsetStart(16);
        decoration.setDividerInsetEnd(16);
        decoration.setLastItemDecorated(false);
        decoration.setDividerThickness(12);
        decoration.setDividerColorResource(this, R.color.black);
        SnapHelper snapHelper = new LinearSnapHelper();
        snapHelper.attachToRecyclerView(rv);

        rv.addItemDecoration(decoration);
        rv.setLayoutManager(new LinearLayoutManager(this));
    }
}
