package com.example.lr27;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class Sensor extends View {
    private final int paintColor = Color.BLACK;
    private Paint drawPaint;
    private List<Point> circlePoints;

    public Sensor(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        /*setFocusable(true);
        setFocusableInTouchMode(true);*/
        setupPaint();
        circlePoints = new ArrayList<Point>();
        setClickable(true);
    }

    private void setupPaint(){
        drawPaint = new Paint();
        drawPaint.setColor(paintColor);
        drawPaint.setAntiAlias(true);
        drawPaint.setStrokeWidth(5);
        //drawPaint.setStyle(Paint.Style.STROKE);
        drawPaint.setStrokeCap(Paint.Cap.ROUND);
        drawPaint.setStrokeJoin(Paint.Join.ROUND);
        drawPaint.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
       for (Point p : circlePoints){
           canvas.drawCircle(p.x,p.y,5,drawPaint);
       }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float touchX = event.getX();
        float touchY = event.getY();
        circlePoints.add(new Point(Math.round(touchX),Math.round(touchY)));
        invalidate();
        //onDraw();
        return true;
    }
}
