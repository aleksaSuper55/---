package com.aiinty.lab37;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ComplexRecyclerViewAdapter complexRecyclerViewAdapter =
                new ComplexRecyclerViewAdapter(getSampleArrayList(), this);
        RecyclerView recyclerView = findViewById(R.id.rv);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(complexRecyclerViewAdapter);
    }

    private ArrayList<Object> getSampleArrayList() {
        ArrayList<Object> items = new ArrayList<>();
        items.add(new User("Anna Ivanova", "Moscow"));
        items.add(new User("Sergey Petrov", "Saint Petersburg"));
        items.add(R.drawable.ic_launcher_background);
        items.add(new User("Olga Smirnova", "Novosibirsk"));
        items.add(R.drawable.ic_launcher_background);
        items.add(new User("Alexey Volkov", "Yekaterinburg"));
        return items;
    }
}