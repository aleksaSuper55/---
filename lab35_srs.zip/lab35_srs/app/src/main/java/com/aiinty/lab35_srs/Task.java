package com.aiinty.lab35_srs;

import java.util.Date;

public class Task {
    private String name;
    private String desc;
    private Boolean isCompleted;
    private Date date;

    public Task(String name, String desc, Boolean isCompleted, Date date) {
        this.name = name;
        this.desc = desc;
        this.isCompleted = isCompleted;
        this.date = date;
    }
    public String getName() {
        return name;
    }
    public String getDesc() {
        return desc;
    }
    public Boolean getCompleted() {
        return isCompleted;
    }
    public Date getDate() {
        return date;
    }
}
