package com.aiinty.lab24;

import androidx.annotation.DrawableRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.res.ResourcesCompat;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Random;
import java.util.function.BiConsumer;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        task1();
        srs();
    }

    private void task1() {
        setContentView(R.layout.activity_main);

        ConstraintLayout constraintLayout = new ConstraintLayout(this);
        ImageView imageView = new ImageView(this);
        Resources res = getResources();
        Drawable drawable = ResourcesCompat.getDrawable(res, R.drawable.tort, null);

        imageView.setImageDrawable(drawable);
        //imageView.setImageResource(R.drawable.tort);

        ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams
                (ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        layoutParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
        imageView.setLayoutParams(layoutParams);
        constraintLayout.addView(imageView);

        setContentView(constraintLayout);
    }

    private final HashMap<Integer, ImageView.ScaleType> buttons = new HashMap<Integer, ImageView.ScaleType>();
    private final @DrawableRes int[] images = {
            R.drawable.pin,
            R.drawable.plus,
            R.drawable.share,
            R.drawable.share_access,
            R.drawable.user
    };

    private Integer currentIdx = 0;
    private ImageView.ScaleType currentScaleType = ImageView.ScaleType.CENTER;
    private TextView imageDetails;

    private void srs() {
        setContentView(R.layout.srs);

        Random random = new Random();

        ImageView image = findViewById(R.id.image_view);
        imageDetails = findViewById(R.id.image_details);

        image.setImageResource(images[currentIdx]);
        image.setScaleType(currentScaleType);
        updateText();

        buttons.put(R.id.center_image, ImageView.ScaleType.CENTER);
        buttons.put(R.id.center_crop_image, ImageView.ScaleType.CENTER_CROP);
        buttons.put(R.id.center_inside_image, ImageView.ScaleType.CENTER_INSIDE);
        buttons.put(R.id.fit_center_image, ImageView.ScaleType.FIT_CENTER);
        buttons.put(R.id.fit_end_image, ImageView.ScaleType.FIT_END);
        buttons.put(R.id.fit_start_image, ImageView.ScaleType.FIT_START);
        buttons.put(R.id.fit_xy_image, ImageView.ScaleType.FIT_XY);
        buttons.put(R.id.matrix_image, ImageView.ScaleType.MATRIX);

        buttons.forEach(new BiConsumer<Integer, ImageView.ScaleType>() {
            @Override
            public void accept(Integer buttonId, ImageView.ScaleType scaleType) {
                Button button = findViewById(buttonId);
                button.setText(scaleType.name());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        currentScaleType = scaleType;
                        image.setScaleType(currentScaleType);
                        updateText();
                    }
                });
            }
        });

        Button randomButton = findViewById(R.id.random_image);
        randomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentIdx = random.nextInt(images.length);
                image.setImageResource(images[currentIdx]);
                updateText();
            }
        });
    }

    private void updateText() {
        imageDetails.setText("Текущая картинка: " + currentIdx
                + "\nТекущее масштабирование: " + currentScaleType.name());
    }

}