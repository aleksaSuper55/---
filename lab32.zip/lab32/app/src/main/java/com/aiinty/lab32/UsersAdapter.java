package com.aiinty.lab32;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class UsersAdapter extends ArrayAdapter<User> {

    private static class ViewHolder {
        TextView name;
        TextView home;
    }

    public UsersAdapter(@NonNull Context context, @NonNull ArrayList<User> objects) {
        super(context, R.layout.item_layout, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        User user = getItem(position);

//        return withoutViewHolder(user, position, parent);
        return withViewHolder(user, position, parent);
    }

    private View withViewHolder(User user, int position, ViewGroup parent) {
        ViewHolder vh = new ViewHolder();
        View convertView =  LayoutInflater.from(getContext()).inflate(R.layout.item_layout,
                parent, false);

        vh.name = convertView.findViewById(R.id.name);
        vh.home = convertView.findViewById(R.id.home);

        Button button = convertView.findViewById(R.id.button);
        Button delete = convertView.findViewById(R.id.delete);
        button.setOnClickListener(v -> {
            Log.e("Button " + position, user.name);
        });
        delete.setOnClickListener(v -> {
            remove(user);
        });

        vh.name.setText(user.name);
        vh.home.setText(user.hometown);

        convertView.setTag(vh);

        return convertView;
    }

    private View withoutViewHolder(User user, int position, ViewGroup parent) {
        View convertView =  LayoutInflater.from(getContext()).inflate(R.layout.item_layout,
                    parent, false);

        TextView nameView = convertView.findViewById(R.id.name);
        TextView homeView = convertView.findViewById(R.id.home);

        Button button = convertView.findViewById(R.id.button);
        Button delete = convertView.findViewById(R.id.delete);
        button.setOnClickListener(v -> {
            Log.e("Button " + position, user.name);
        });
        delete.setOnClickListener(v -> {
            remove(user);
        });

        nameView.setText(user.name);
        homeView.setText(user.hometown);

        return convertView;
    }
}
