package com.example.listapp2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Button but;

    ArrayList<State> states = new ArrayList<State>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        but = findViewById(R.id.but);
        RecyclerView recyclerView = findViewById(R.id.list);
        StateAdapter.OnStateClickListener stateClickListener = new StateAdapter.OnStateClickListener() {
            @Override
            public void onStateClick(State state, int position) {

                Toast.makeText(getApplicationContext(), "Нажата страна " + state.getName(),
                        Toast.LENGTH_SHORT).show();
            }
        };
        StateAdapter adapter = new StateAdapter(this, states, stateClickListener);
        recyclerView.setAdapter(adapter);
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setInitialData();
                recyclerView.setVisibility(View.VISIBLE);
            }
        });
    }
    private void setInitialData() {
        states.add(new State ("Бразилия", "Бразилиа", R.drawable.br));
        states.add(new State ("Черногория", "Подгорица", R.drawable.cher));
        states.add(new State ("Турция", "Анкара", R.drawable.tyr));
        states.add(new State ("Россия", "Москва", R.drawable.r));
        states.add(new State ("Япония", "Токио", R.drawable.yp));
    }
}