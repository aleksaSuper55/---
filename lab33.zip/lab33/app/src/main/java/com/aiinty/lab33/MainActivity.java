package com.aiinty.lab33;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        ArrayList<Element> colors = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            colors.add(new Element("Blue " + i, Color.BLUE));
            colors.add(new Element("Green " + i, Color.GREEN));
            colors.add(new Element("Red " + i, Color.RED));
        }

        ElementArrayAdapter adapter = new ElementArrayAdapter(this, colors);
        listView.setAdapter(adapter);
    }


}

class ElementArrayAdapter extends ArrayAdapter<Element> {

    public ElementArrayAdapter(@NonNull Context context, @NonNull ArrayList<Element> objects) {
        super(context, 0, objects);
    }

    @Override
    public int getViewTypeCount() {
        return Color.values().length;
    }

    @Override
    public int getItemViewType(int position) {
        return Objects.requireNonNull(getItem(position)).color.ordinal();
    }

    private View getInflatedLayout(int type) {
        HashMap<Integer, Integer> table = new HashMap() {{
            put(Color.BLUE.ordinal(), R.layout.blue_element);
            put(Color.RED.ordinal(), R.layout.red_element);
            put(Color.GREEN.ordinal(), R.layout.green_element);
        }};

        return LayoutInflater.from(getContext()).inflate(table.get(type), null);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            int type = getItemViewType(position);
            convertView = getInflatedLayout(type);
        }

        TextView label = convertView.findViewById(R.id.label);

        if (label != null) {
            label.setText(Objects.requireNonNull(getItem(position)).label);
        }

        return convertView;
    }
}