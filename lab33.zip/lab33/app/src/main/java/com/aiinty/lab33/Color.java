package com.aiinty.lab33;

public enum Color {
    RED, BLUE, GREEN;

}