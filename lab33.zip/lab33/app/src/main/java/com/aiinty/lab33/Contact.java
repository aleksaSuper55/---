package com.aiinty.lab33;

public class Contact {
    public String name;
    public String phone;
    public String email;
    public Status status;

    public Contact(String name, String phone, String email, Status status) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.status = status;
    }
}
