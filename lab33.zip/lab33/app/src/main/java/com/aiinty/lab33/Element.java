package com.aiinty.lab33;

public class Element {
    public String label;
    public Color color;

    public Element(String label, Color color) {
        this.label = label;
        this.color = color;
    }
}
