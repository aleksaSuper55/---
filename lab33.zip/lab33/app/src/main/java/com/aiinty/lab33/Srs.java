package com.aiinty.lab33;

import static androidx.core.content.ContextCompat.getColor;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Objects;
import java.util.function.Function;

public class Srs extends AppCompatActivity {

    ListView contactsView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_srs);

        contactsView = findViewById(R.id.contactsListView);

        contactsView.setAdapter(new ContactArrayAdapter(this, new ArrayList<Contact>(Arrays.asList(
                new Contact("Andrew", "+79681020329","",Status.ONLINE),
                new Contact("Andrew", "+79681020329","",Status.DND),
                new Contact("Andrew", "+79681020329","",Status.IDLE),
                new Contact("Vanya", "","sigmaboy@ifdhs.ru",Status.OFFLINE)
        ))));
    }
}

class ContactArrayAdapter extends ArrayAdapter<Contact> {
    public ContactArrayAdapter(@NonNull Context context, @NonNull ArrayList<Contact> objects) {
        super(context, 0, objects);
    }

    @Override
    public int getViewTypeCount() {
        return Status.values().length;
    }

    @Override
    public int getItemViewType(int position) {
        return Objects.requireNonNull(getItem(position)).status.ordinal();
    }

    private View getInflatedLayout(int type) {


        return LayoutInflater.from(getContext()).inflate(R.layout.contact_element, null);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            int type = getItemViewType(position);
            convertView = getInflatedLayout(type);
        }

        TextView name = convertView.findViewById(R.id.contactName);
        TextView phoneEmail = convertView.findViewById(R.id.contactEmailPhone);
        Button status = convertView.findViewById(R.id.activityButton);

        if (name != null && phoneEmail != null && status != null) {
            Contact item = getItem(position);
            assert item != null;
            name.setText(Objects.requireNonNull(item.name));

            phoneEmail.setText("Пусто");
            if (item.phone.isEmpty()) {
                phoneEmail.setText(item.email);
            }
            if (item.email.isEmpty()) {
                phoneEmail.setText(item.phone);
            }

            setEffect(status, item);

            status.setOnClickListener(v -> {
                    if (item.status.ordinal() + 1 >= Status.DND.ordinal()) {
                        item.status = Status.ONLINE;
                    } else {
                        item.status = Status.values()[item.status.ordinal() + 1];
                    }
                setEffect(status, item);
            });
        }

        return convertView;
    }

    void setEffect(Button status, Contact item) {
        status.setText(item.status.name());

        switch (item.status) {
            case ONLINE:
                status.getBackground().setTint(0xFF88E788);
                break;
            case IDLE:
                status.getBackground().setTint(0xFFFFB66B);
                break;
            case DND:
                status.getBackground().setTint(0xFFFF474C);
                break;
            case OFFLINE:
                status.getBackground().setTint(0x0F000000);
                break;
        }
    }
}



