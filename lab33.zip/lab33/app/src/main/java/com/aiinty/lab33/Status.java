package com.aiinty.lab33;

public enum Status {
    ONLINE,
    OFFLINE,
    IDLE,
    DND,
}
